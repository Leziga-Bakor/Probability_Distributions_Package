from setuptools import setup

setup(name='Probability_Distributions_LB',
      version='0.1.0',
      description='Gaussian and Binomial distributions',
      packages=['Probability_Distributions_LB'],
      zip_safe=False)